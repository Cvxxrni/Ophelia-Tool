Ophelia! We are glad to have you here.

To start, run Ophelia setup .exe

If you need any help, you can contact our support team at ! J0nas 1935
Enjoy!